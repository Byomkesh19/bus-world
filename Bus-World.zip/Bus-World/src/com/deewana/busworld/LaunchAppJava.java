package com.deewana.busworld;

import com.deewana.busworld.ui.CustomerHomePage;
import com.deewana.busworld.ui.LoginUser;

public class LaunchAppJava {
	public static void main(String[] args) {
		
		LoginUser loginUser=new CustomerHomePage();
		loginUser.login();
		
	}

}
